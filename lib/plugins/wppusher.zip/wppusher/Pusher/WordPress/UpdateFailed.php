<?php

namespace Pusher\WordPress;

use Exception;

class UpdateFailed extends Exception
{
}
